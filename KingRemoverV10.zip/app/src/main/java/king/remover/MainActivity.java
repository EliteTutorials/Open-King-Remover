package king.remover;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.support.v7.app.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.io.*;
import java.util.*;

import android.support.v7.app.AlertDialog;
import java.lang.Process;

// All credits go to the massive android community
public class MainActivity extends Activity
{
	Button button;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);



		//LoadFiles
		{

			File One = new File(getFilesDir(), "helper.sh");
			File Two = new File(getFilesDir(), "busybox");
			File Three = new File(getFilesDir(), "su");
			try
			{
				InputStream one = getAssets().open("helper.sh");
				OutputStream oneOut = new FileOutputStream(One);
				InputStream two = getAssets().open("busybox");
				OutputStream twoOut = new FileOutputStream(Two);
				InputStream three = getAssets().open("su");
				OutputStream threeOut = new FileOutputStream(Three);
				byte[] buffer1 = new byte[1024];
				int in1;
				while ((in1 = one.read(buffer1)) > 0)
				{
					oneOut.write(buffer1, 0, in1);
				}
				byte[] buffer2 = new byte[1024];
				int in2;
				while ((in2 = two.read(buffer2)) > 0)
				{
					twoOut.write(buffer2, 0, in2);
				}
				byte[] buffer3 = new byte[1024];
				int in3;
				while ((in3 = three.read(buffer3)) > 0)
				{
					threeOut.write(buffer3, 0, in3);
				}

				one.close();
				oneOut.close();
				two.close();
				twoOut.close();
				three.close();
			    threeOut.close();
			}
			catch (FileNotFoundException ex)
			{
				System.exit(0);
			}
			catch (IOException e)
			{
				System.exit(0);
			}
		}
		/*-------------------------
		 ASK ROOT ON START
		 -------------------------*/
		if (isRooted() == false)
		{
			AlertDialog.Builder alertDial = new AlertDialog.Builder(MainActivity.this);
			alertDial.setCancelable(false);
			alertDial.setTitle("Root Error");
			alertDial.setMessage("You probably need root for this app !");
			alertDial.setNeutralButton("                                               EXIT                                               ", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which)
					{
						System.exit(0);
					}
				});
			alertDial.setIcon(R.drawable.ic_launcher);
			alertDial.show();
		}
		else
		{
			updateStatus(null);
		}

		{
			button = (Button) findViewById(R.id.button1);
			button.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v)
					{
						AlertDialog.Builder alertDial = new AlertDialog.Builder(MainActivity.this);
						alertDial.setTitle("Remove King Soft")
							.setMessage("This will edit your system, backup your system if your worried. This will try to override kingroot with a temp root method")				
							.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int whichButton)
								{
									final ProgressDialog pd = new ProgressDialog(MainActivity.this);
									pd.setIndeterminate(true);
									pd.setCancelable(false);
									pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
									pd.show();
									new Thread(new Runnable() {
											@Override
											public void run()
											{
												try
												{
													String permissions[]={"su","-c", "chmod 0700 /data/data/king.remover/files/helper.sh"}; 
													try
													{
														Process process = Runtime.getRuntime().exec(permissions);
														process.waitFor();
														{
															String execscript[]={"su","-c", "sh /data/data/king.remover/files/helper.sh"}; 
															try
															{
																Process process2 = Runtime.getRuntime().exec(execscript);
																process2.waitFor();
																try
																{
																
																}
																catch (Exception e)
																{ 
																}
																finally
																{
																	SharedPreferences.Editor editor = getPreferences(0).edit();
																	editor.putString("isFinished=", "yes");
																	editor.commit();   
																	updateStatus(null);
																}

															}
															catch (IOException e)
															{
																e.printStackTrace();}
														}

													}
													catch (IOException e)
													{
														e.printStackTrace();
													}

												}
												catch (Exception e)
												{
													e.printStackTrace();
												}
												finally
												{
													pd.dismiss();
												}
											}
										}).start();
//---------------------------------CODE BREAK-----------------------------------------
								}
							}).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int whichButton)
								{
									// Do nothing.
								}
							}).show();

					};
				});
		}
	}
	public static boolean isRooted()
	{
		{
			Process process = null;
			try
			{
				process = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
				try
				{
					process.waitFor();
					BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
					String output = in.readLine();
					if (output.toLowerCase().contains("uid=0"))
						return true;
				}
				catch (InterruptedException e)
				{
					return false;
				}	
			}
			catch (Exception e)
			{
				return false;
			}
			finally
			{
				if (process != null)
				{
					process.destroy();
				}
			}

		}
		return false;
	}
	public boolean isPackageInstalled(String targetPackage)
	{
        List<ApplicationInfo> packages;
        PackageManager pm;
        pm = getPackageManager();        
        packages = pm.getInstalledApplications(0);
        for (ApplicationInfo packageInfo : packages)
		{
            if (packageInfo.packageName.equals(targetPackage))
                return true;
        }
        return false;
    }

	public void updateStatus(View view)
	{
			boolean appFound = isPackageInstalled("com.kingroot.RushRoot");

		if (appFound == true)
		{
			SharedPreferences.Editor editor = getPreferences(0).edit();
			editor.putString("wasInstalled=", "yes");
			editor.commit();  
			TextView status = (TextView) findViewById(R.id.status);
			status.setText("King Software Is Installed");
		}
		else if (appFound == false)
		{
			TextView status = (TextView) findViewById(R.id.status);
			status.setText("King Software Is Not Found");
			SharedPreferences prefs = getPreferences(0); 
			String isFinished= prefs.getString("isFinished=", "no").toString();
			if (isFinished.equals("yes"))
			{
				AlertDialog.Builder alertDial = new AlertDialog.Builder(this);
				alertDial.setCancelable(false);
				alertDial.setTitle("Install Root Manager");
				alertDial.setMessage("King Software was removed, Please install a root manager now !");
				alertDial.setPositiveButton("                                                                           OK                                                                           ", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which)
						{
							System.exit(0);
						}
					});
				alertDial.setIcon(R.drawable.ic_launcher);
				alertDial.show();
			}
			else if (!isFinished.equals("yes"))
			{
				AlertDialog.Builder alertDial = new AlertDialog.Builder(this);
				alertDial.setCancelable(false);
				alertDial.setTitle("NO KING SOFTWARE FOUND");
				alertDial.setMessage("You can not use KingRem' without having king software to remove !");
				alertDial.setPositiveButton("                                                                           OK                                                                           ", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which)
						{
							System.exit(0);
						}
					});
				alertDial.setIcon(R.drawable.ic_launcher);
				alertDial.show();
			}
		}

	}
}
